const express = require("express");
const bcrypt = require("bcryptjs");
const session = require("express-session");
const fs = require("fs");
const path = require("path");

const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

app.use(
  session({
    secret: "secureSecretKey",
    resave: false,
    saveUninitialized: false,
  })
);

// Helper functions
const readUsers = () => {
  if (!fs.existsSync("users.json")) return [];
  return JSON.parse(fs.readFileSync("users.json"));
};

const writeUsers = (users) => {
  fs.writeFileSync("users.json", JSON.stringify(users, null, 2));
};

// Home
app.get("/", (req, res) => {
  res.redirect("/login.html");
});

// Register
app.post("/register", async (req, res) => {
  const { username, password } = req.body;
  const users = readUsers();

  // Check if user exists
  if (users.find((u) => u.username === username)) {
    return res.send("User already exists!");
  }

  // Hash password
  const hashedPassword = await bcrypt.hash(password, 10);

  users.push({ username, password: hashedPassword });
  writeUsers(users);

  res.redirect("/login.html");
});

// Login
app.post("/login", async (req, res) => {
  const { username, password } = req.body;
  const users = readUsers();

  const user = users.find((u) => u.username === username);
  if (!user) {
    return res.send("Invalid credentials");
  }

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    return res.send("Invalid credentials");
  }

  req.session.user = username;
  res.redirect("/dashboard");
});

// Protected Dashboard
app.get("/dashboard", (req, res) => {
  if (req.session.user) {
    res.sendFile(path.join(__dirname, "public/dashboard.html"));
  } else {
    res.redirect("/login.html");
  }
});

// Logout
app.get("/logout", (req, res) => {
  req.session.destroy();
  res.redirect("/login.html");
});

// Server
app.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
